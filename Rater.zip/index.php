<?php
session_start();
require("./phpFunc/utils.php");
require("./phpFunc/counters.php");
require("./phpFunc/DB_connect.php");


$title ="Rater";
require("./view/landing.phtml");
?>



