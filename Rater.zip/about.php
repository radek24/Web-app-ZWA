<?php
session_start();
require("./view/head.phtml");
require("./phpFunc/utils.php")

?>

    <div class="container pt-5 ">

        <h1 class="display-2" style="font-weight: bold; padding-top:7%">ABOUT</h1>


    <h3 style="font-weight:lighter;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, ipsa repellendus! Cumque doloremque nisi modi minima. Deserunt necessitatibus vero, provident aliquid repellendus eos explicabo fugiat nemo, voluptas maxime earum quasi iste hic at nam nulla totam dicta sint temporibus libero id. Accusamus tenetur dolorem aut sint architecto vero delectus esse distinctio eveniet minus pariatur inventore, nisi nostrum adipisci. Vel beatae ducimus, repellat alias eveniet placeat minima unde voluptatum, numquam ut fuga, dicta dolorem quas voluptas laudantium mollitia aliquid id nam aliquam velit! Rem voluptatem omnis et officia velit facere. <br><br>Iure accusamus atque ipsum iste tempora dolor perspiciatis assumenda in vel nemo optio quam quibusdam doloribus ut ratione. Unde veniam perspiciatis illo fugit tempora nihil tempore amet velit aspernatur, eius esse laborum officiis, exercitationem in, ab accusantium! Similique rem accusantium blanditiis? Quasi ipsam tempore facere suscipit velit deserunt. <br><br>Tenetur accusantium repellat eaque porro adipisci, molestias quas ut sed alias molestiae animi recusandae ullam labore ea commodi cum cupiditate? Nihil rem eaque consequuntur ducimus rerum tempore eligendi veniam ab, reprehenderit dolore distinctio cum ut molestiae. Nam qui assumenda vero quod molestias maxime, in non placeat reiciendis! Voluptas dolore quas, consectetur eaque iure commodi quisquam. Quae quas enim repellat ducimus voluptates ab. <br><br>Numquam ratione vitae dolor, consectetur illum expedita maxime facilis nihil inventore aliquam. Aliquid obcaecati enim, architecto laudantium excepturi doloribus maxime omnis iste eum facere repudiandae esse! <br><br>Cum dolor necessitatibus a natus odio voluptates quaerat accusamus beatae, consequatur aliquid velit, odit earum, aspernatur optio magnam fugiat fuga laborum recusandae veritatis! Consectetur, blanditiis reprehenderit aut, eaque harum ducimus tempora minus repellat doloribus illo placeat omnis dolore dolores. Delectus commodi veniam officia. Veniam aliquam nesciunt perferendis qui deleniti ducimus, aliquid, architecto ad facere nihil eaque dolorum optio doloribus tempore vero. Amet repellat modi impedit incidunt, deleniti architecto voluptatem ad non. Officiis, earum! Aut, officiis.</h3>
    <h1 class="display-2" style="font-weight: bold; padding-top:7%">Q&A</h1>  
    <h3 style="font-weight:lighter;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Accusamus eum repudiandae veniam illo? Dignissimos deserunt nesciunt repudiandae eligendi suscipit veniam? <br><br> - Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reprehenderit explicabo nesciunt possimus omnis ipsam deserunt consequuntur praesentium dolorum minima architecto.<br><br><h3>
    <h3 style="font-weight:lighter;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Accusamus eum repudiandae veniam illo? Dignissimos deserunt nesciunt repudiandae eligendi suscipit veniam? <br><br> - Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reprehenderit explicabo nesciunt possimus omnis ipsam deserunt consequuntur praesentium dolorum minima architecto.<br><br><h3>
    <h3 style="font-weight:lighter;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Accusamus eum repudiandae veniam illo? Dignissimos deserunt nesciunt repudiandae eligendi suscipit veniam? <br><br> - Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reprehenderit explicabo nesciunt possimus omnis ipsam deserunt consequuntur praesentium dolorum minima architecto.<br><br><h3>
    <h3 style="font-weight:lighter;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Accusamus eum repudiandae veniam illo? Dignissimos deserunt nesciunt repudiandae eligendi suscipit veniam? <br><br> - Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reprehenderit explicabo nesciunt possimus omnis ipsam deserunt consequuntur praesentium dolorum minima architecto.<br><br><h3>

</div>
    



<?php
require("./view/footer.phtml");
?>