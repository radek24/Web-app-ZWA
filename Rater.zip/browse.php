<?php
session_start();
require("./view/head.phtml");
require("./phpFunc/utils.php")

?>

    <div class="container pt-5 ">

        <h1 class="display-2" style="font-weight: bold; padding-top:7%">BROWSE ARTISTS</h1>
    </div>


<?php
require("./view/footer.phtml");
?>