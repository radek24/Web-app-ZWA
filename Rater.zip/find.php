

<?php
session_start();
$title = "Rater - Find";
require("./view/head.phtml");
require("./view/find.phtml");
require("./view/footer.phtml");
?>