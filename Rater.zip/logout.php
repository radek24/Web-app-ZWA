<?php
session_start();
require("./phpFunc/user.php");
logoff();